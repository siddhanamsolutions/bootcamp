package com.example.crudapp.service;

import com.example.crudapp.exception.ResourceNotFoundException;
import com.example.crudapp.model.Student;
import com.example.crudapp.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Student Service
 * Contains business logic for Student operations
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class StudentService {

    private final StudentRepository studentRepository;

    /**
     * Get all students
     */
    public List<Student> getAllStudents() {
        log.info("Fetching all students");
        List<Student> students = studentRepository.findAll();
        log.info("Found {} students", students.size());
        return students;
    }

    /**
     * Get student by ID
     */
    public Student getStudentById(Long id) {
        log.info("Fetching student with id: {}", id);
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("Student ID must be a positive number");
        }
        return studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student", "id", id));
    }

    /**
     * Create a new student
     */
    public Student createStudent(Student student) {
        log.info("Creating new student: {}", student.getEmail());
        
        // Check if email already exists
        if (studentRepository.existsByEmail(student.getEmail())) {
            throw new IllegalArgumentException("Email already exists: " + student.getEmail());
        }
        
        Student savedStudent = studentRepository.save(student);
        log.info("Student created successfully with id: {}", savedStudent.getId());
        return savedStudent;
    }

    /**
     * Update an existing student
     */
    public Student updateStudent(Long id, Student studentDetails) {
        log.info("Updating student with id: {}", id);
        
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("Student ID must be a positive number");
        }

        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student", "id", id));

        // Check if email is being changed and if it already exists
        if (!student.getEmail().equals(studentDetails.getEmail()) && 
            studentRepository.existsByEmail(studentDetails.getEmail())) {
            throw new IllegalArgumentException("Email already exists: " + studentDetails.getEmail());
        }

        // Update fields
        student.setFirstName(studentDetails.getFirstName());
        student.setLastName(studentDetails.getLastName());
        student.setEmail(studentDetails.getEmail());
        student.setPhone(studentDetails.getPhone());
        student.setGpa(studentDetails.getGpa());
        student.setEnrollmentDate(studentDetails.getEnrollmentDate());

        Student updatedStudent = studentRepository.save(student);
        log.info("Student updated successfully with id: {}", updatedStudent.getId());
        return updatedStudent;
    }

    /**
     * Delete a student
     */
    public void deleteStudent(Long id) {
        log.info("Deleting student with id: {}", id);
        
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("Student ID must be a positive number");
        }

        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student", "id", id));

        studentRepository.delete(student);
        log.info("Student deleted successfully with id: {}", id);
    }

    /**
     * Search students by query (name, email)
     */
    public List<Student> searchStudents(String query) {
        log.info("Searching students with query: {}", query);
        
        if (query == null || query.trim().isEmpty()) {
            throw new IllegalArgumentException("Search query cannot be empty");
        }

        List<Student> results = studentRepository.searchStudents(query.trim());
        log.info("Found {} students matching query: {}", results.size(), query);
        return results;
    }

    /**
     * Get students with GPA >= specified value
     */
    public List<Student> getStudentsByMinGPA(Double minGPA) {
        log.info("Fetching students with minimum GPA: {}", minGPA);
        
        if (minGPA == null || minGPA < 0 || minGPA > 4.0) {
            throw new IllegalArgumentException("GPA must be between 0.0 and 4.0");
        }

        return studentRepository.findByGpaGreaterThanEqual(minGPA);
    }

    /**
     * Get students with GPA < specified value
     */
    public List<Student> getStudentsByMaxGPA(Double maxGPA) {
        log.info("Fetching students with maximum GPA: {}", maxGPA);
        
        if (maxGPA == null || maxGPA < 0 || maxGPA > 4.0) {
            throw new IllegalArgumentException("GPA must be between 0.0 and 4.0");
        }

        return studentRepository.findByGpaLessThan(maxGPA);
    }

    /**
     * Get student count
     */
    public long getStudentCount() {
        log.info("Getting total student count");
        return studentRepository.count();
    }

    /**
     * Check if student exists
     */
    public boolean studentExists(Long id) {
        return id != null && id > 0 && studentRepository.existsById(id);
    }
}
