package com.example.crudapp.repository;

import com.example.crudapp.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Student Repository
 * Provides database access methods for Student entity
 */
@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {

    /**
     * Find student by email
     */
    Optional<Student> findByEmail(String email);

    /**
     * Search students by first name or last name
     */
    @Query("SELECT s FROM Student s WHERE " +
           "LOWER(s.firstName) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(s.lastName) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(s.email) LIKE LOWER(CONCAT('%', :query, '%'))")
    List<Student> searchStudents(@Param("query") String query);

    /**
     * Find students with GPA greater than or equal to specified value
     */
    List<Student> findByGpaGreaterThanEqual(Double gpa);

    /**
     * Find students with GPA less than specified value
     */
    List<Student> findByGpaLessThan(Double gpa);

    /**
     * Check if email exists
     */
    boolean existsByEmail(String email);

    /**
     * Find students by last name
     */
    List<Student> findByLastNameIgnoreCase(String lastName);

    /**
     * Find students by first name
     */
    List<Student> findByFirstNameIgnoreCase(String firstName);
}
