package com.example.crudapp.config;

import com.example.crudapp.model.Student;
import com.example.crudapp.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;

/**
 * Data Initialization Configuration
 * Populates the database with sample student data on application startup
 */
@Configuration
@Slf4j
public class DataInitializerConfig {

    @Bean
    public CommandLineRunner initializeData(StudentRepository studentRepository) {
        return args -> {
            log.info("Initializing database with sample student data...");

            // Create sample students
            Student student1 = new Student();
            student1.setFirstName("John");
            student1.setLastName("Doe");
            student1.setEmail("john.doe@university.edu");
            student1.setPhone("5551234567");
            student1.setGpa(3.8);
            student1.setEnrollmentDate(LocalDate.of(2023, 9, 1));

            Student student2 = new Student();
            student2.setFirstName("Jane");
            student2.setLastName("Smith");
            student2.setEmail("jane.smith@university.edu");
            student2.setPhone("5559876543");
            student2.setGpa(3.5);
            student2.setEnrollmentDate(LocalDate.of(2023, 9, 1));

            Student student3 = new Student();
            student3.setFirstName("Michael");
            student3.setLastName("Johnson");
            student3.setEmail("michael.johnson@university.edu");
            student3.setPhone("5555551234");
            student3.setGpa(2.9);
            student3.setEnrollmentDate(LocalDate.of(2022, 9, 1));

            Student student4 = new Student();
            student4.setFirstName("Emily");
            student4.setLastName("Williams");
            student4.setEmail("emily.williams@university.edu");
            student4.setPhone("5555559876");
            student4.setGpa(3.2);
            student4.setEnrollmentDate(LocalDate.of(2023, 9, 1));

            Student student5 = new Student();
            student5.setFirstName("David");
            student5.setLastName("Brown");
            student5.setEmail("david.brown@university.edu");
            student5.setPhone("5555553333");
            student5.setGpa(3.9);
            student5.setEnrollmentDate(LocalDate.of(2023, 9, 1));

            // Save all students
            studentRepository.save(student1);
            studentRepository.save(student2);
            studentRepository.save(student3);
            studentRepository.save(student4);
            studentRepository.save(student5);

            log.info("Sample data initialization completed. Total students: {}", studentRepository.count());
        };
    }
}
