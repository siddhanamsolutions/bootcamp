package com.example.crudapp.controller;

import com.example.crudapp.model.Student;
import com.example.crudapp.service.StudentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Student REST Controller
 * Provides endpoints for CRUD operations on students
 */
@RestController
@RequestMapping("/api/students")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "http://localhost:4200", allowedHeaders = "*", methods = {
        RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS
})
public class StudentController {

    private final StudentService studentService;

    /**
     * GET /api/students - Get all students
     */
    @GetMapping
    public ResponseEntity<List<Student>> getAllStudents() {
        log.info("GET /api/students - Getting all students");
        List<Student> students = studentService.getAllStudents();
        return ResponseEntity.ok(students);
    }

    /**
     * GET /api/students/{id} - Get student by ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable Long id) {
        log.info("GET /api/students/{} - Getting student by id", id);
        Student student = studentService.getStudentById(id);
        return ResponseEntity.ok(student);
    }

    /**
     * POST /api/students - Create a new student
     */
    @PostMapping
    public ResponseEntity<Student> createStudent(@Valid @RequestBody Student student) {
        log.info("POST /api/students - Creating new student");
        Student createdStudent = studentService.createStudent(student);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdStudent);
    }

    /**
     * PUT /api/students/{id} - Update an existing student
     */
    @PutMapping("/{id}")
    public ResponseEntity<Student> updateStudent(
            @PathVariable Long id,
            @Valid @RequestBody Student studentDetails) {
        log.info("PUT /api/students/{} - Updating student", id);
        Student updatedStudent = studentService.updateStudent(id, studentDetails);
        return ResponseEntity.ok(updatedStudent);
    }

    /**
     * DELETE /api/students/{id} - Delete a student
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteStudent(@PathVariable Long id) {
        log.info("DELETE /api/students/{} - Deleting student", id);
        studentService.deleteStudent(id);
        return ResponseEntity.ok(Map.of("message", "Student deleted successfully"));
    }

    /**
     * GET /api/students/search?query=... - Search students
     */
    @GetMapping("/search")
    public ResponseEntity<List<Student>> searchStudents(@RequestParam String query) {
        log.info("GET /api/students/search?query={} - Searching students", query);
        List<Student> results = studentService.searchStudents(query);
        return ResponseEntity.ok(results);
    }

    /**
     * GET /api/students/filter/min-gpa?gpa=... - Get students by minimum GPA
     */
    @GetMapping("/filter/min-gpa")
    public ResponseEntity<List<Student>> getStudentsByMinGPA(@RequestParam Double gpa) {
        log.info("GET /api/students/filter/min-gpa?gpa={} - Getting students by min GPA", gpa);
        List<Student> students = studentService.getStudentsByMinGPA(gpa);
        return ResponseEntity.ok(students);
    }

    /**
     * GET /api/students/filter/max-gpa?gpa=... - Get students by maximum GPA
     */
    @GetMapping("/filter/max-gpa")
    public ResponseEntity<List<Student>> getStudentsByMaxGPA(@RequestParam Double gpa) {
        log.info("GET /api/students/filter/max-gpa?gpa={} - Getting students by max GPA", gpa);
        List<Student> students = studentService.getStudentsByMaxGPA(gpa);
        return ResponseEntity.ok(students);
    }

    /**
     * GET /api/students/count - Get total student count
     */
    @GetMapping("/count")
    public ResponseEntity<Map<String, Long>> getStudentCount() {
        log.info("GET /api/students/count - Getting total student count");
        long count = studentService.getStudentCount();
        return ResponseEntity.ok(Map.of("count", count));
    }

    /**
     * Health check endpoint
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        log.info("GET /api/students/health - Health check");
        return ResponseEntity.ok(Map.of("status", "API is running successfully"));
    }
}
