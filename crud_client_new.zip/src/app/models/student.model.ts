export interface Student {
  id?: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  gpa: number;
  enrollmentDate: string;
}
