import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { StudentService } from '../../services/student.service';
import { Student } from '../../models/student.model';

@Component({
  selector: 'app-student-detail',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './student-detail.component.html',
  styleUrl: './student-detail.component.css'
})
export class StudentDetailComponent implements OnInit {
  student: Student | null = null;
  isLoading: boolean = false;
  errorMessage: string = '';

  constructor(
    private studentService: StudentService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.loadStudent(parseInt(id));
    }
  }

  /**
   * Load student details by ID
   */
  loadStudent(id: number): void {
    this.isLoading = true;
    this.errorMessage = '';
    this.studentService.getStudentById(id).subscribe({
      next: (data: Student) => {
        this.student = data;
        this.isLoading = false;
      },
      error: (error) => {
        this.errorMessage = 'Failed to load student details. Please try again.';
        console.error('Error loading student:', error);
        this.isLoading = false;
      }
    });
  }

  /**
   * Go back to student list
   */
  goBack(): void {
    this.router.navigate(['/students']);
  }

  /**
   * Delete the current student
   */
  deleteStudent(): void {
    if (!this.student?.id) return;

    if (confirm('Are you sure you want to delete this student? This action cannot be undone.')) {
      this.studentService.deleteStudent(this.student.id).subscribe({
        next: () => {
          alert('Student deleted successfully');
          this.router.navigate(['/students']);
        },
        error: (error) => {
          this.errorMessage = 'Failed to delete student.';
          console.error('Error deleting student:', error);
        }
      });
    }
  }

  /**
   * Calculate academic status based on GPA
   */
  getAcademicStatus(gpa: number): string {
    if (gpa >= 3.5) return 'Excellent';
    if (gpa >= 3.0) return 'Good';
    if (gpa >= 2.0) return 'Satisfactory';
    return 'Below Average';
  }

  /**
   * Get status badge color
   */
  getStatusColor(gpa: number): string {
    if (gpa >= 3.5) return 'status-excellent';
    if (gpa >= 3.0) return 'status-good';
    if (gpa >= 2.0) return 'status-satisfactory';
    return 'status-poor';
  }
}
