import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StudentService } from '../../services/student.service';
import { Student } from '../../models/student.model';

@Component({
  selector: 'app-student-create',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './student-create.component.html',
  styleUrl: './student-create.component.css'
})
export class StudentCreateComponent {
  studentForm!: FormGroup;
  isSubmitting: boolean = false;
  errorMessage: string = '';
  successMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private studentService: StudentService,
    private router: Router
  ) {
    this.initializeForm();
  }

  /**
   * Initialize the form with validators
   */
  initializeForm(): void {
    this.studentForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      gpa: ['', [Validators.required, Validators.min(0), Validators.max(4)]],
      enrollmentDate: ['', Validators.required]
    });
  }

  /**
   * Submit the form and create a new student
   */
  onSubmit(): void {
    if (this.studentForm.invalid) {
      this.markFormGroupTouched(this.studentForm);
      return;
    }

    this.isSubmitting = true;
    this.errorMessage = '';
    this.successMessage = '';

    const student: Student = this.studentForm.value;

    this.studentService.createStudent(student).subscribe({
      next: (response) => {
        this.successMessage = 'Student created successfully!';
        this.isSubmitting = false;
        setTimeout(() => {
          this.router.navigate(['/students', response.id]);
        }, 1500);
      },
      error: (error) => {
        this.errorMessage = 'Failed to create student. Please try again.';
        console.error('Error creating student:', error);
        this.isSubmitting = false;
      }
    });
  }

  /**
   * Mark all form fields as touched to show validation errors
   */
  markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.get(key);
      control?.markAsTouched();
    });
  }

  /**
   * Cancel and go back to student list
   */
  cancel(): void {
    this.router.navigate(['/students']);
  }

  /**
   * Get error message for a form field
   */
  getErrorMessage(fieldName: string): string {
    const control = this.studentForm.get(fieldName);
    if (!control || !control.errors || !control.touched) {
      return '';
    }

    if (control.errors['required']) {
      return `${this.capitalize(fieldName)} is required`;
    }
    if (control.errors['minLength']) {
      return `${this.capitalize(fieldName)} must be at least ${control.errors['minLength'].requiredLength} characters`;
    }
    if (control.errors['email']) {
      return 'Please enter a valid email';
    }
    if (control.errors['pattern']) {
      return 'Phone must be 10 digits';
    }
    if (control.errors['min'] || control.errors['max']) {
      return `${this.capitalize(fieldName)} must be between 0 and 4`;
    }
    return 'Invalid input';
  }

  /**
   * Capitalize first letter of string
   */
  capitalize(str: string): string {
    return str.charAt(0).toUpperCase() + str.slice(1).replace(/([A-Z])/g, ' $1');
  }

  /**
   * Check if field has error and is touched
   */
  hasError(fieldName: string): boolean {
    const control = this.studentForm.get(fieldName);
    return !!(control && control.invalid && control.touched);
  }
}
