import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { StudentService } from '../../services/student.service';
import { Student } from '../../models/student.model';

@Component({
  selector: 'app-student-list',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './student-list.component.html',
  styleUrl: './student-list.component.css'
})
export class StudentListComponent implements OnInit {
  students: Student[] = [];
  searchTerm: string = '';
  isLoading: boolean = false;
  errorMessage: string = '';

  constructor(private studentService: StudentService) { }

  ngOnInit(): void {
    this.loadStudents();
  }

  /**
   * Load all students from the API
   */
  loadStudents(): void {
    this.isLoading = true;
    this.errorMessage = '';
    this.studentService.getAllStudents().subscribe({
      next: (data: Student[]) => {
        this.students = data;
        this.isLoading = false;
      },
      error: (error) => {
        this.errorMessage = 'Failed to load students. Please check your API connection.';
        console.error('Error loading students:', error);
        this.isLoading = false;
      }
    });
  }

  /**
   * Search students by name or email
   */
  search(): void {
    if (this.searchTerm.trim() === '') {
      this.loadStudents();
      return;
    }
    this.isLoading = true;
    this.errorMessage = '';
    this.studentService.searchStudents(this.searchTerm).subscribe({
      next: (data: Student[]) => {
        this.students = data;
        this.isLoading = false;
      },
      error: (error) => {
        this.errorMessage = 'Search failed. Please try again.';
        console.error('Error searching students:', error);
        this.isLoading = false;
      }
    });
  }

  /**
   * Delete a student
   */
  deleteStudent(id: number | undefined): void {
    if (!id) return;
    
    if (confirm('Are you sure you want to delete this student?')) {
      this.studentService.deleteStudent(id).subscribe({
        next: () => {
          this.students = this.students.filter(s => s.id !== id);
          alert('Student deleted successfully');
        },
        error: (error) => {
          this.errorMessage = 'Failed to delete student.';
          console.error('Error deleting student:', error);
        }
      });
    }
  }

  /**
   * Clear search and reload all students
   */
  clearSearch(): void {
    this.searchTerm = '';
    this.loadStudents();
  }
}
