import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from '../../services/student.service';
import { Student } from '../../models/student.model';

@Component({
  selector: 'app-student-edit',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './student-edit.component.html',
  styleUrl: './student-edit.component.css'
})
export class StudentEditComponent implements OnInit {
  studentForm!: FormGroup;
  isSubmitting: boolean = false;
  isLoading: boolean = false;
  errorMessage: string = '';
  successMessage: string = '';
  studentId: number | null = null;

  constructor(
    private fb: FormBuilder,
    private studentService: StudentService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.initializeForm();
  }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.studentId = parseInt(id);
      this.loadStudent(this.studentId);
    }
  }

  /**
   * Initialize the form with validators
   */
  initializeForm(): void {
    this.studentForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      gpa: ['', [Validators.required, Validators.min(0), Validators.max(4)]],
      enrollmentDate: ['', Validators.required]
    });
  }

  /**
   * Load student data to populate the form
   */
  loadStudent(id: number): void {
    this.isLoading = true;
    this.errorMessage = '';
    this.studentService.getStudentById(id).subscribe({
      next: (student: Student) => {
        this.studentForm.patchValue({
          firstName: student.firstName,
          lastName: student.lastName,
          email: student.email,
          phone: student.phone,
          gpa: student.gpa,
          enrollmentDate: student.enrollmentDate
        });
        this.isLoading = false;
      },
      error: (error) => {
        this.errorMessage = 'Failed to load student details.';
        console.error('Error loading student:', error);
        this.isLoading = false;
      }
    });
  }

  /**
   * Submit the form and update the student
   */
  onSubmit(): void {
    if (this.studentForm.invalid) {
      this.markFormGroupTouched(this.studentForm);
      return;
    }

    if (!this.studentId) return;

    this.isSubmitting = true;
    this.errorMessage = '';
    this.successMessage = '';

    const student: Student = this.studentForm.value;

    this.studentService.updateStudent(this.studentId, student).subscribe({
      next: (response) => {
        this.successMessage = 'Student updated successfully!';
        this.isSubmitting = false;
        setTimeout(() => {
          this.router.navigate(['/students', this.studentId]);
        }, 1500);
      },
      error: (error) => {
        this.errorMessage = 'Failed to update student. Please try again.';
        console.error('Error updating student:', error);
        this.isSubmitting = false;
      }
    });
  }

  /**
   * Mark all form fields as touched to show validation errors
   */
  markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.get(key);
      control?.markAsTouched();
    });
  }

  /**
   * Cancel and go back to student detail
   */
  cancel(): void {
    this.router.navigate(['/students', this.studentId]);
  }

  /**
   * Get error message for a form field
   */
  getErrorMessage(fieldName: string): string {
    const control = this.studentForm.get(fieldName);
    if (!control || !control.errors || !control.touched) {
      return '';
    }

    if (control.errors['required']) {
      return `${this.capitalize(fieldName)} is required`;
    }
    if (control.errors['minLength']) {
      return `${this.capitalize(fieldName)} must be at least ${control.errors['minLength'].requiredLength} characters`;
    }
    if (control.errors['email']) {
      return 'Please enter a valid email';
    }
    if (control.errors['pattern']) {
      return 'Phone must be 10 digits';
    }
    if (control.errors['min'] || control.errors['max']) {
      return `${this.capitalize(fieldName)} must be between 0 and 4`;
    }
    return 'Invalid input';
  }

  /**
   * Capitalize first letter of string
   */
  capitalize(str: string): string {
    return str.charAt(0).toUpperCase() + str.slice(1).replace(/([A-Z])/g, ' $1');
  }

  /**
   * Check if field has error and is touched
   */
  hasError(fieldName: string): boolean {
    const control = this.studentForm.get(fieldName);
    return !!(control && control.invalid && control.touched);
  }
}
